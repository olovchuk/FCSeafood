-- Priority:2
IF NOT EXISTS(SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_User]') AND name = N'PK_User')
BEGIN
    CREATE TABLE [dbo].[T_User]
    (
        [PK_User]        [uniqueidentifier] NOT NULL,
        [First_Name]     [nvarchar](30)     NOT NULL,
        [Last_Name]      [nvarchar](30)     NOT NULL,
        [FK_Role_Type]   [int]              NOT NULL,
        [FK_Gender_Type] [int]              NOT NULL,
        [IsActive]       [bit]              NOT NULL,
        [IsVerified]     [bit]              NOT NULL,
        [Phone]          [nvarchar](30)     NULL,
        [Image_Path]     [nvarchar](MAX)    NULL,
        [Date_Of_Birth]  [datetime]         NULL,
        [FK_Address]     [uniqueidentifier] NULL,
        [Created_Date]   [datetime]         NOT NULL,
        [Updated_Date]   [datetime]         NOT NULL,
        PRIMARY KEY CLUSTERED
            ([PK_User] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [dbo].[T_User] ADD CONSTRAINT [DF_T_User_PK_User] DEFAULT (NEWID()) FOR [PK_User]

    ALTER TABLE [dbo].[T_User] ADD CONSTRAINT [FK_T_User_FK_Role_Type] FOREIGN KEY ([FK_Role_Type])
        REFERENCES [enum].[E_Role_Type] ([PK_Role_Type])
    ALTER TABLE [dbo].[T_User] CHECK CONSTRAINT [FK_T_User_FK_Role_Type]

    ALTER TABLE [dbo].[T_User] ADD CONSTRAINT [FK_T_User_FK_Gender_Type] FOREIGN KEY ([FK_Gender_Type])
        REFERENCES [enum].[E_Gender_Type] ([PK_Gender_Type])
    ALTER TABLE [dbo].[T_User] CHECK CONSTRAINT [FK_T_User_FK_Gender_Type]

    ALTER TABLE [dbo].[T_User] ADD CONSTRAINT [DF_T_User_IsActive] DEFAULT ((1)) FOR [IsActive]

    ALTER TABLE [dbo].[T_User] ADD CONSTRAINT [DF_T_User_IsVerified] DEFAULT ((0)) FOR [IsVerified]

    ALTER TABLE [dbo].[T_User] ADD CONSTRAINT [FK_T_User_FK_Address] FOREIGN KEY ([FK_Address])
        REFERENCES [dbo].[T_Address] ([PK_Address])
    ALTER TABLE [dbo].[T_User] CHECK CONSTRAINT [FK_T_User_FK_Address]

    ALTER TABLE [dbo].[T_User] ADD CONSTRAINT [DF_T_User_Created_Date] DEFAULT (SYSDATETIME()) FOR [Created_Date]

    ALTER TABLE [dbo].[T_User] ADD CONSTRAINT [DF_T_User_Updated_Date] DEFAULT (SYSDATETIME()) FOR [Updated_Date]
END
GO