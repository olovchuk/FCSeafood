-- Priority:6
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_Order_Entity]') AND name = N'PK_Order_Entity')
BEGIN
    CREATE TABLE [dbo].[T_Order]
    (
        [PK_Order]     [uniqueidentifier] NOT NULL,
        [FK_User]      [uniqueidentifier] NOT NULL,
		[Total_Price]  [float]            NOT NULL,
        [Created_Date] [datetime]         NOT NULL,
		[IsComplete]   [bit]              NOT NULL
            PRIMARY KEY CLUSTERED
                ([PK_Order] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [dbo].[T_Order] ADD CONSTRAINT [DF_T_Order_PK_Order] DEFAULT (NEWID()) FOR [PK_Order]

    ALTER TABLE [dbo].[T_Order] ADD CONSTRAINT [FK_T_Order_FK_User] FOREIGN KEY ([FK_User])
        REFERENCES [dbo].[T_User] ([PK_User])
    ALTER TABLE [dbo].[T_Order] CHECK CONSTRAINT [FK_T_Order_FK_User]

	ALTER TABLE [dbo].[T_Order] ADD CONSTRAINT [DF_T_Order_IsComplete] DEFAULT ((0)) FOR [IsComplete]
END
GO