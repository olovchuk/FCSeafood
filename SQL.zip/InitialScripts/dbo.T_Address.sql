-- Priority:1
IF NOT EXISTS(SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_Address]') AND name = N'PK_Address')
BEGIN
    CREATE TABLE [dbo].[T_Address]
    (
        [PK_Address]       [uniqueidentifier] NOT NULL,
        [Country]          [nvarchar](50)     NOT NULL,
        [City]             [nvarchar](50)     NOT NULL,
        [Street]           [nvarchar](50)     NOT NULL,
        [Apartment_Number] [int]              NOT NULL,
        [Entrance]         [int]              NULL,
        [Floor]            [int]              NULL,
        [Intercom]         [int]              NULL,
        [Zip_Code]         [nvarchar](10)     NULL,
        PRIMARY KEY CLUSTERED
            ([PK_Address] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

	ALTER TABLE [dbo].[T_Address] ADD CONSTRAINT [DF_T_Address_PK_Address] DEFAULT (NEWID()) FOR [PK_Address]
END
GO