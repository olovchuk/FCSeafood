DELETE FROM [dbo].[T_Email_Template]
DELETE [dbo].[T_Email_Template]
GO

SET IDENTITY_INSERT [dbo].[T_Email_Template] ON
INSERT [dbo].[T_Email_Template] ([PK_Email_Template],[Code],[Subject],[Body]) VALUES 
(1, 'RESET_PASSWORD_CONFIRM','Reset password',
'<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css2?family=Martel+Sans:wght@400;600;700&family=Martel:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body style="background-color: #f1f1f1; margin: 0; padding: 0; font-family: Martel Sans, sans-serif; display: flex; justify-content: center;">
<table border="0" width="100%" height="100%" cellpadding="0" cellspacing="0" bgcolor="#f5f5f5">
    <tr valign="middle">
        <td align="center" valign="top" style="padding: 30px 0;">
            <table border="0" align="center" valign="top" width="700" cellpadding="0" cellspacing="0" bgcolor="#ffffff" style="width: 600px;">
                <tr>
                    <td style="background-color: #197275; height: 10px;"></td>
                </tr>
                <tr>
                    <td style="padding-top: 10px;">
                        <a href="https://lc.fcseafood.com/" title="FCSeafood" target="_blank" style="text-decoration: none; color: #000000;">
                            <table align="center">
                                <tr valign="middle">
                                    <td>
                                        <img src="https://i.imgur.com/YGerZ2N.png" alt="FCSeafood logo" height="61px" width="200px" style="height: 61px; width: 200px;">
                                    </td>
                                </tr>
                            </table>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td style="background-color: #197275; width: 90%; height: 2px"></td>
                </tr>
                <tr>
                    <td style="padding: 15px; text-indent: 20px;">
                        Dear {{UserFullName}},
                    </td>
                </tr>
                <tr>
                    <td style="padding: 15px; text-indent: 20px;">
                        We have received a request to make changes to your account information.
                        If you would like to confirm the password change, please click on the "Confirm" button.
                        The confirmation will be valid for 10 minutes.
                    </td>
                </tr>
                <tr>
                    <td style="padding-bottom: 20px;">
                        <table align="center">
                            <tr valign="middle">
                                <td>
                                    <a style="background-color: #197275; text-decoration: none; color: white; padding: 9px;" href="{{ConfirmUrl}}">Confirm</a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td style="background-color: #272727; height: 60px; padding: 0 10px;">
                        <table align="right" style="height: 100%">
                            <tr valign="middle">
                                <td style="color: white; font-size: 12px">FCSeafood, All rights reserved</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>'
),
(2, 'FORGOT_PASSWORD','Forgot password',
'<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css2?family=Martel+Sans:wght@400;600;700&family=Martel:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body style="background-color: #f1f1f1; margin: 0; padding: 0; font-family: Martel Sans, sans-serif; display: flex; justify-content: center;">
<table border="0" width="100%" height="100%" cellpadding="0" cellspacing="0" bgcolor="#f5f5f5">
    <tr valign="middle">
        <td align="center" valign="top" style="padding: 30px 0;">
            <table border="0" align="center" valign="top" width="700" cellpadding="0" cellspacing="0" bgcolor="#ffffff" style="width: 600px;">
                <tr>
                    <td style="background-color: #197275; height: 10px;"></td>
                </tr>
                <tr>
                    <td style="padding-top: 10px;">
                        <a href="https://lc.fcseafood.com/" title="FCSeafood" target="_blank" style="text-decoration: none; color: #000000;">
                            <table align="center">
                                <tr valign="middle">
                                    <td>
                                        <img src="https://i.imgur.com/YGerZ2N.png" alt="FCSeafood logo" height="61px" width="200px" style="height: 61px; width: 200px;">
                                    </td>
                                </tr>
                            </table>
                        </a>
                    </td>
                </tr>
                <tr>
                    <td style="background-color: #197275; width: 90%; height: 2px"></td>
                </tr>
                <tr>
                    <td style="padding: 15px; text-indent: 20px;">
                        Dear {{UserFullName}},
                    </td>
                </tr>
                <tr>
                    <td style="padding: 15px; text-indent: 20px;">
                        We have received a request to make changes to your account information.
                        Your password has been reset.
                    </td>
                </tr>
                <tr>
                    <td style="padding: 15px; text-indent: 20px;">
                        New password: {{NewPassword}}
                    </td>
                </tr>
                <tr>
                    <td style="background-color: #272727; height: 60px; padding: 0 10px;">
                        <table align="right" style="height: 100%">
                            <tr valign="middle">
                                <td style="color: white; font-size: 12px">FCSeafood, All rights reserved</td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>'
)
SET IDENTITY_INSERT [dbo].[T_Email_Template] OFF