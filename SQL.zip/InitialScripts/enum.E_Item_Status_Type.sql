IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[enum].[E_Item_Status_Type]') AND name = N'PK_Item_Status_Type')
BEGIN
    CREATE TABLE [enum].[E_Item_Status_Type]
    (
        [PK_Item_Status_Type] [int] IDENTITY (1,1) NOT NULL,
        [Name]                [nvarchar](50)       NOT NULL,
        PRIMARY KEY CLUSTERED
            ([PK_Item_Status_Type] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO

DELETE [enum].[E_Item_Status_Type]
GO

SET IDENTITY_INSERT [enum].[E_Item_Status_Type] ON
INSERT [enum].[E_Item_Status_Type] ([PK_Item_Status_Type], [Name])
    VALUES (0, N'N/A'),
           (1, N'Available'),
           (2, N'Ended'),
           (3, N'Deleted')
SET IDENTITY_INSERT [enum].[E_Item_Status_Type] OFF