-- Priority:4
IF NOT EXISTS(SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_Item]') AND name = N'PK_Item')
BEGIN
    CREATE TABLE [dbo].[T_Item]
    (
        [PK_Item]                    [uniqueidentifier] NOT NULL,
        [Name]                       [nvarchar](255)    NOT NULL,
        [Code]                       [nvarchar](50)     NOT NULL,
		[Image_Path]                 [nvarchar](255)    NOT NULL,
        [Price]                      [float]            NOT NULL,
        [FK_Category_Type]           [int]              NOT NULL,
        [FK_Subcategory_Type]        [int]              NOT NULL,
        [FK_Item_Status_Type]        [int]              NOT NULL,
        [Quantity_Per_Kg]            [float]            NOT NULL,
		[Like_Count]                 [int]              NOT NULL,
		[Dislike_Count]              [int]              NOT NULL,
        [Brand]                      [nvarchar](50)     NULL,
        [Type]                       [nvarchar](50)     NULL,
        [Finishing]                  [nvarchar](50)     NULL,
        [IsPackaging]                [bit]              NOT NULL,
        [Fats_Per_100_Gram]          [float]            NULL,
        [Carbohydrates_Per_100_Gram] [float]            NULL,
        [Proteins_Per_100_Gram]      [float]            NULL,
        [Kcal_Per_100_Gram]          [float]            NULL,
        [Humidity_Per_Percent]       [float]            NULL,
        [Expiration_Date]            [datetime]         NOT NULL,
        [Temperature_Storage]        [float]            NOT NULL,
        [FK_Temperature_Unit]        [int]              NOT NULL,
        [Description]                [nvarchar](MAX)    NULL
        PRIMARY KEY CLUSTERED
            ([PK_Item] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
        CONSTRAINT [UN_T_Item_Code] UNIQUE NONCLUSTERED
            ([Code] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [dbo].[T_Item] ADD CONSTRAINT [DF_T_Item_PK_Item] DEFAULT (NEWID()) FOR [PK_Item]

    ALTER TABLE [dbo].[T_Item] ADD CONSTRAINT [FK_T_Item_FK_Category_Type] FOREIGN KEY ([FK_Category_Type])
        REFERENCES [enum].[E_Category_Type] ([PK_Category_Type])
    ALTER TABLE [dbo].[T_Item] CHECK CONSTRAINT [FK_T_Item_FK_Category_Type]

    ALTER TABLE [dbo].[T_Item] ADD CONSTRAINT [FK_T_Item_FK_Subcategory_Type] FOREIGN KEY ([FK_Subcategory_Type])
        REFERENCES [enum].[E_Subcategory_Type] ([PK_Subcategory_Type])
    ALTER TABLE [dbo].[T_Item] CHECK CONSTRAINT [FK_T_Item_FK_Subcategory_Type]

    ALTER TABLE [dbo].[T_Item] ADD CONSTRAINT [DF_T_Item_Like_Count] DEFAULT ((0)) FOR [Like_Count]

	ALTER TABLE [dbo].[T_Item] ADD CONSTRAINT [DF_T_Item_Dislike_Count] DEFAULT ((0)) FOR [Dislike_Count]
	
	ALTER TABLE [dbo].[T_Item] ADD CONSTRAINT [DF_T_Item_IsPackaging] DEFAULT ((0)) FOR [IsPackaging]

    ALTER TABLE [dbo].[T_Item] ADD CONSTRAINT [FK_T_Item_FK_Temperature_Unit] FOREIGN KEY ([FK_Temperature_Unit])
        REFERENCES [enum].[E_Temperature_Unit] ([PK_Temperature_Unit])
    ALTER TABLE [dbo].[T_Item] CHECK CONSTRAINT [FK_T_Item_FK_Temperature_Unit]

    ALTER TABLE [dbo].[T_Item] ADD CONSTRAINT [FK_T_Item_FK_Item_Status] FOREIGN KEY ([FK_Item_Status_Type])
        REFERENCES [enum].[E_Item_Status_Type] ([PK_Item_Status_Type])
    ALTER TABLE [dbo].[T_Item] CHECK CONSTRAINT [FK_T_Item_FK_Item_Status]
END
GO