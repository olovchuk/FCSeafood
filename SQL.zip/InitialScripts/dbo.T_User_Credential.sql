-- Priority:3
IF NOT EXISTS(SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_User_Credentials]') AND name = 'PK_User')
BEGIN
    CREATE TABLE [dbo].[T_User_Credentials]
    (
        [PK_User]                    [uniqueidentifier] NOT NULL,
        [Email]                      [varchar](255)     NOT NULL,
        [Password]                   [nvarchar](255)    NOT NULL,
        [Last_Login_Date]            [datetime2](2)     NULL,
        [Last_Password_Changed_Date] [datetime2](2)     NULL,
        PRIMARY KEY CLUSTERED
            ([PK_User] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
        CONSTRAINT [UN_T_User_Credentials_Email] UNIQUE NONCLUSTERED
            ([Email] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [dbo].[T_User_Credentials] ADD CONSTRAINT [FK_T_User_Credentials_PK_User] FOREIGN KEY ([PK_User])
        REFERENCES [dbo].[T_User] ([PK_User])
    ALTER TABLE [dbo].[T_User_Credentials] CHECK CONSTRAINT [FK_T_User_Credentials_PK_User]
END
GO