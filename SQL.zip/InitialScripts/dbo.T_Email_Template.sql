-- Priority:9
IF NOT EXISTS(SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_Email_Template]') AND name = N'PK_Email_Template')
BEGIN
    CREATE TABLE [dbo].[T_Email_Template]
    (
        [PK_Email_Template] [int] IDENTITY (1,1) NOT NULL,
        [Code]              [nvarchar](50)       NOT NULL,
        [Subject]           [nvarchar](50)       NOT NULL,
        [Body]              [nvarchar](max)      NOT NULL
        PRIMARY KEY CLUSTERED
            ([PK_Email_Template] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
		CONSTRAINT [UN_T_Email_Template_Code] UNIQUE NONCLUSTERED
			([Code] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO