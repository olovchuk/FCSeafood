IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[enum].[E_Rating_Type]') AND name = N'PK_Rating_Type')
BEGIN
    CREATE TABLE [enum].[E_Rating_Type]
    (
        [PK_Rating_Type] [int] IDENTITY (1,1) NOT NULL,
        [Name]           [nvarchar](50)       NOT NULL,
        PRIMARY KEY CLUSTERED
            ([PK_Rating_Type] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO

DELETE [enum].[E_Rating_Type]
GO

SET IDENTITY_INSERT [enum].[E_Rating_Type] ON
INSERT [enum].[E_Rating_Type] ([PK_Rating_Type], [Name])
    VALUES (0, N'N/A'),
           (1, N'Like'),
           (2, N'Dislike')
SET IDENTITY_INSERT [enum].[E_Rating_Type] OFF