-- Priority:7
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_Order_Entity]') AND name = N'PK_Order_Entit')
BEGIN
    CREATE TABLE [dbo].[T_Order_Entity]
    (
        [PK_Order_Entity] [uniqueidentifier] NOT NULL,
        [FK_Order]        [uniqueidentifier] NOT NULL,
        [FK_Item]         [uniqueidentifier] NOT NULL,
        [Quantity_Per_Kg] [float]            NOT NULL,
		[Price]           [float]            NOT NULL
            PRIMARY KEY CLUSTERED
                ([PK_Order_Entity] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [dbo].[T_Order_Entity] ADD CONSTRAINT [DF_T_Order_Entity_PK_Order_Entit] DEFAULT (NEWID()) FOR [PK_Order_Entity]

    ALTER TABLE [dbo].[T_Order_Entity] ADD CONSTRAINT [FK_T_Order_Entity_FK_Order] FOREIGN KEY ([FK_Order])
        REFERENCES [dbo].[T_Order] ([PK_Order])
    ALTER TABLE [dbo].[T_Order_Entity] CHECK CONSTRAINT [FK_T_Order_Entity_FK_Order]

    ALTER TABLE [dbo].[T_Order_Entity] ADD CONSTRAINT [FK_T_Order_Entity_FK_Item] FOREIGN KEY ([FK_Item])
        REFERENCES [dbo].[T_Item] ([PK_Item])
    ALTER TABLE [dbo].[T_Order_Entity] CHECK CONSTRAINT [FK_T_Order_Entity_FK_Item]
END
GO