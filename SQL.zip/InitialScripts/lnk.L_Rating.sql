IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[lnk].[L_Rating]') AND name = N'PK_Rating')
BEGIN
    CREATE TABLE [lnk].[L_Rating]
    (
        [PK_Rating]      [uniqueidentifier] NOT NULL,
        [FK_User]        [uniqueidentifier] NOT NULL,
        [FK_Item]        [uniqueidentifier] NOT NULL,
        [FK_Rating_Type] [int]              NOT NULL
        PRIMARY KEY CLUSTERED
            ([PK_Rating] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [lnk].[L_Rating] ADD CONSTRAINT [DF_L_Rating_PK_Rating] DEFAULT (NEWID()) FOR [PK_Rating]

    ALTER TABLE [lnk].[L_Rating] ADD CONSTRAINT [FK_L_Rating_FK_User] FOREIGN KEY ([FK_User])
        REFERENCES [dbo].[T_User] ([PK_User])
    ALTER TABLE [lnk].[L_Rating] CHECK CONSTRAINT [FK_L_Rating_FK_User]

    ALTER TABLE [lnk].[L_Rating] ADD CONSTRAINT [FK_L_Rating_FK_Item] FOREIGN KEY ([FK_Item])
        REFERENCES [dbo].[T_Item] ([PK_Item])
    ALTER TABLE [lnk].[L_Rating] CHECK CONSTRAINT [FK_L_Rating_FK_Item]


    ALTER TABLE [lnk].[L_Rating] ADD CONSTRAINT [FK_L_Rating_FK_Rating_Type] FOREIGN KEY ([FK_Rating_Type])
        REFERENCES [enum].[E_Rating_Type] ([PK_Rating_Type])
    ALTER TABLE [lnk].[L_Rating] CHECK CONSTRAINT [FK_L_Rating_FK_Rating_Type]
END
GO