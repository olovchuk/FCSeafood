IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[enum].[E_Gender_Type]') AND name = N'PK_Gender_Type')
BEGIN
    CREATE TABLE [enum].[E_Gender_Type]
    (
        [PK_Gender_Type] [int] IDENTITY (1,1) NOT NULL,
        [Name]           [nvarchar](20)       NOT NULL,
        PRIMARY KEY CLUSTERED
            ([PK_Gender_Type] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO

DELETE [enum].[E_Gender_Type]
GO

SET IDENTITY_INSERT [enum].[E_Gender_Type] ON
INSERT [enum].[E_Gender_Type] ([PK_Gender_Type], [Name])
    VALUES (0, N'N/A'),
           (1, N'Male'),
           (2, N'Female'),
           (3, N'Other')
SET IDENTITY_INSERT [enum].[E_Gender_Type] OFF