IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[enum].[E_Delivery_Status_Type]') AND name = N'PK_Delivery_Status_Type')
BEGIN
    CREATE TABLE [enum].[E_Delivery_Status_Type]
    (
        [PK_Delivery_Status_Type] [int] IDENTITY (1,1) NOT NULL,
        [Name]                    [nvarchar](50)       NOT NULL,
        PRIMARY KEY CLUSTERED
            ([PK_Delivery_Status_Type] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO

DELETE [enum].[E_Delivery_Status_Type]
GO

SET IDENTITY_INSERT [enum].[E_Delivery_Status_Type] ON
INSERT [enum].[E_Delivery_Status_Type] ([PK_Delivery_Status_Type], [Name])
    VALUES (0, N'N/A'),
           (1, N'Pending'),
           (2, N'In process'),
           (3, N'Delivered'),
           (4, N'Undelivered'),
           (5, N'Rejected'),
           (6, N'Return'),
           (7, N'Delayed'),
           (8, N'Cancelled')
SET IDENTITY_INSERT [enum].[E_Delivery_Status_Type] OFF