IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[enum].[E_Subcategory_Type]') AND name = N'PK_Subcategory_Type')
BEGIN
    CREATE TABLE [enum].[E_Subcategory_Type]
    (
        [PK_Subcategory_Type] [int] IDENTITY (1,1) NOT NULL,		
		[FK_Category_Type]    [int]                NOT NULL,
        [Name]                [nvarchar](50)       NOT NULL,
		[Image_Path]          [nvarchar](255)      NOT NULL
        PRIMARY KEY CLUSTERED
            ([PK_Subcategory_Type] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

	ALTER TABLE [enum].[E_Subcategory_Type] ADD CONSTRAINT [FK_E_Subcategory_Type_FK_Category_Type] FOREIGN KEY ([FK_Category_Type])
        REFERENCES [enum].[E_Category_Type] ([PK_Category_Type])
    ALTER TABLE [enum].[E_Subcategory_Type] CHECK CONSTRAINT [FK_E_Subcategory_Type_FK_Category_Type]
END
GO

DELETE [enum].[E_Subcategory_Type]
GO

SET IDENTITY_INSERT [enum].[E_Subcategory_Type] ON
INSERT [enum].[E_Subcategory_Type] ([PK_Subcategory_Type], [FK_Category_Type], [Name], [Image_Path])
    VALUES (0, 0, N'N/A', N'assets/images/subcategory-type/unknown.png'),
           -- Fish
           (1, 1, N'Sea fish', N'assets/images/subcategory-type/unknown.png'),
           (2, 1, N'River fish', N'assets/images/subcategory-type/unknown.png'),
           (3, 1, N'Lake fish', N'assets/images/subcategory-type/unknown.png'),
           -- Caviar
           (4, 2, N'Red caviar', N'assets/images/subcategory-type/red-caviar.png'),
           (5, 2, N'Black sturgeon caviar', N'assets/images/subcategory-type/black-caviar.png'),
           (6, 2, N'Cod caviar', N'assets/images/subcategory-type/cod-caviar.png'),
           (7, 2, N'Pike caviar', N'assets/images/subcategory-type/pike-caviar.png'),
           -- Seafood
           (8, 3, N'Mussels', N'assets/images/subcategory-type/mussels.png'),
           (9, 3, N'Squid', N'assets/images/subcategory-type/squid.png'),
           (10, 3, N'Octopus', N'assets/images/subcategory-type/octopus.png'),
           (11, 3, N'Rapani', N'assets/images/subcategory-type/rapani.png'),
           (12, 3, N'Seafood cocktail', N'assets/images/subcategory-type/seafood-cocktail.png'),
           (13, 3, N'Shrimp', N'assets/images/subcategory-type/shrimp.png'),
           (14, 3, N'Live oyster', N'assets/images/subcategory-type/live-oyster.png'),
           (15, 3, N'Pectinida', N'assets/images/subcategory-type/pectinida.png'),
		   -- Crabs crayfish
		   (16, 4, N'Crabs', N'assets/images/subcategory-type/crab.png'),
		   (17, 4, N'Crayfish', N'assets/images/subcategory-type/crayfish.png'),
		   (18, 4, N'Lobster', N'assets/images/subcategory-type/crab.png'),
		   (19, 4, N'Omar', N'assets/images/subcategory-type/crab.png')
SET IDENTITY_INSERT [enum].[E_Subcategory_Type] OFF