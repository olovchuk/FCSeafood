IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[lnk].[L_Reset_Password]') AND name = N'PK_Reset_Password')
BEGIN
    CREATE TABLE [lnk].[L_Reset_Password]
    (
        [PK_Reset_Password] [int] IDENTITY(1,1) NOT NULL,
        [FK_User]           [uniqueidentifier]  NOT NULL,
		[Code]              [int]               NOT NULL,
        [Created_Date]      [datetime]          NOT NULL,
        [Expiration_Date]   [datetime]          NOT NULL,
        PRIMARY KEY CLUSTERED
            ([PK_Reset_Password] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [lnk].[L_Reset_Password] ADD CONSTRAINT [FK_L_Reset_Password_FK_User] FOREIGN KEY ([FK_User])
        REFERENCES [dbo].[T_User] ([PK_User])
    ALTER TABLE [lnk].[L_Reset_Password] CHECK CONSTRAINT [FK_L_Reset_Password_FK_User]

	ALTER TABLE [lnk].[L_Reset_Password] ADD CONSTRAINT [DF_L_Reset_Password_Created_Date] DEFAULT (SYSDATETIME()) FOR [Created_Date]

    ALTER TABLE [lnk].[L_Reset_Password] ADD CONSTRAINT [DF_L_Reset_Password_Expiration_Date] DEFAULT (SYSDATETIME()) FOR [Expiration_Date]
END
GO