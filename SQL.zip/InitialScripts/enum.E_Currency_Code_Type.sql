IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[enum].[E_Currency_Code_Type]') AND name = N'PK_Currency_Code_Type')
BEGIN
    CREATE TABLE [enum].[E_Currency_Code_Type]
    (
        [PK_Currency_Code_Type] [int] IDENTITY (1,1) NOT NULL,
        [Name]                  [nvarchar](3)        NOT NULL,
        PRIMARY KEY CLUSTERED
            ([PK_Currency_Code_Type] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]
END
GO

DELETE [enum].[E_Currency_Code_Type]
GO

SET IDENTITY_INSERT [enum].[E_Currency_Code_Type] ON
INSERT [enum].[E_Currency_Code_Type] ([PK_Currency_Code_Type], [Name])
    VALUES (0, N'N/A'),
           (1, N'UAH'),
           (2, N'USD')
SET IDENTITY_INSERT [enum].[E_Currency_Code_Type] OFF