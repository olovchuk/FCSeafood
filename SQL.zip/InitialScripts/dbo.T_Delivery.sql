-- Priority:8
IF NOT EXISTS(SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_Delivery]') AND name = N'PK_Delivery')
BEGIN
    CREATE TABLE [dbo].[T_Delivery]
    (
        [PK_Delivery]             [uniqueidentifier] NOT NULL,
        [Tracking_Number]         [nvarchar](49)     NOT NULL,
        [FK_User]                 [uniqueidentifier] NOT NULL,
        [FK_Courier]              [uniqueidentifier] NULL,
        [FK_Order]                [uniqueidentifier] NOT NULL,
        [FK_Delivery_Status_Type] [int]              NOT NULL,
        [FK_Payment_Method_Type]  [int]              NOT NULL,
        [Notes]                   [nvarchar](500)    NULL,
        [Created_Date]            [datetime]         NOT NULL
        PRIMARY KEY CLUSTERED
            ([PK_Delivery] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
        CONSTRAINT [UN_T_Delivery_Tracking_Number] UNIQUE NONCLUSTERED
            ([Tracking_Number] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [dbo].[T_Delivery] ADD CONSTRAINT [DF_T_Delivery_PK_Delivery] DEFAULT (NEWID()) FOR [PK_Delivery]

    ALTER TABLE [dbo].[T_Delivery] ADD CONSTRAINT [FK_T_Delivery_FK_User] FOREIGN KEY ([FK_User])
        REFERENCES [dbo].[T_User] ([PK_User])
    ALTER TABLE [dbo].[T_Delivery] CHECK CONSTRAINT [FK_T_Delivery_FK_User]

    ALTER TABLE [dbo].[T_Delivery] ADD CONSTRAINT [FK_T_Delivery_FK_Courier] FOREIGN KEY ([FK_Courier])
        REFERENCES [dbo].[T_User] ([PK_User])
    ALTER TABLE [dbo].[T_Delivery] CHECK CONSTRAINT [FK_T_Delivery_FK_Courier]

    ALTER TABLE [dbo].[T_Delivery] ADD CONSTRAINT [FK_T_Delivery_FK_Order] FOREIGN KEY ([FK_Order])
        REFERENCES [dbo].[T_Order] ([PK_Order])
    ALTER TABLE [dbo].[T_Delivery] CHECK CONSTRAINT [FK_T_Delivery_FK_Order]

    ALTER TABLE [dbo].[T_Delivery] ADD CONSTRAINT [DF_T_Delivery_Created_Date] DEFAULT (SYSDATETIME()) FOR [Created_Date]
END
GO