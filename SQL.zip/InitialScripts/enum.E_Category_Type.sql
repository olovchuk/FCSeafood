﻿IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[enum].[E_Category_Type]') AND name = N'PK_Category_Type')
BEGIN
    CREATE TABLE [enum].[E_Category_Type]
	(
		[PK_Category_Type] [int] IDENTITY (1,1) NOT NULL,
		[Name]             [nvarchar](20)       NOT NULL,
		[Image_Path]       [nvarchar](255)      NOT NULL,
		PRIMARY KEY CLUSTERED
			([PK_Category_Type] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]
END
GO

DELETE [enum].[E_Category_Type]
GO

SET IDENTITY_INSERT [enum].[E_Category_Type] ON
INSERT [enum].[E_Category_Type] ([PK_Category_Type], [Name], [Image_Path])
    VALUES (0, N'N/A', N'assets/images/category-type/unknown.png'),
           (1, N'Fish', N'assets/images/category-type/fish.png'),
           (2, N'Caviar', N'assets/images/category-type/caviar.png'),
           (3, N'Seafood', N'assets/images/category-type/seafood.png'),
		   (4, N'Crabs crayfish', N'assets/images/category-type/crabs-crayfish.png')
SET IDENTITY_INSERT [enum].[E_Category_Type] OFF