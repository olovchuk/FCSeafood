-- Priority:5
IF NOT EXISTS(SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'[dbo].[T_Comment]') AND name = N'PK_Comment')
BEGIN
    CREATE TABLE [dbo].[T_Comment]
    (
        [PK_Comment]        [uniqueidentifier] NOT NULL,
        [FK_User]           [uniqueidentifier] NOT NULL,
        [FK_Item]           [uniqueidentifier] NOT NULL,
        [Title]             [nvarchar](50)     NOT NULL,
        [Text]              [nvarchar](MAX)    NOT NULL,
        [IsModify]          [bit]              NOT NULL,
        [FK_Parent_Comment] [uniqueidentifier] NULL,
        [Created_Date]      [datetime2](2)     NOT NULL,
        [Updated_Date]      [datetime2](2)     NULL,
        PRIMARY KEY CLUSTERED
            ([PK_Comment] ASC) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
    ) ON [PRIMARY]

    ALTER TABLE [dbo].[T_Comment] ADD CONSTRAINT [DF_T_Comment_PK_Comment] DEFAULT (NEWID()) FOR [PK_Comment]

    ALTER TABLE [dbo].[T_Comment] ADD CONSTRAINT [FK_T_Comment_FK_User] FOREIGN KEY ([FK_User])
        REFERENCES [dbo].[T_User] ([PK_User])
    ALTER TABLE [dbo].[T_Comment] CHECK CONSTRAINT [FK_T_Comment_FK_User]

    ALTER TABLE [dbo].[T_Comment] ADD CONSTRAINT [FK_T_Comment_FK_Item] FOREIGN KEY ([FK_Item])
        REFERENCES [dbo].[T_Item] ([PK_Item])
    ALTER TABLE [dbo].[T_Comment] CHECK CONSTRAINT [FK_T_Comment_FK_Item]

    ALTER TABLE [dbo].[T_Comment] ADD CONSTRAINT [DF_T_Comment_IsModify] DEFAULT ((0)) FOR [IsModify]

    ALTER TABLE [dbo].[T_Comment] ADD CONSTRAINT [FK_T_Comment_FK_Parent_Comment] FOREIGN KEY ([FK_Parent_Comment])
        REFERENCES [dbo].[T_Comment] ([PK_Comment])
    ALTER TABLE [dbo].[T_Comment] CHECK CONSTRAINT [FK_T_Comment_FK_Parent_Comment]

    ALTER TABLE [dbo].[T_Comment] ADD CONSTRAINT [DF_T_Comment_Created_Date] DEFAULT (SYSUTCDATETIME()) FOR [Created_Date]
END
GO