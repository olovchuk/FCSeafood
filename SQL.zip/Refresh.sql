USE [master]
GO
ALTER DATABASE [Test] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
USE [master]
GO
/****** Object:  Database [Test]  ******/
DROP DATABASE [Test]
GO
CREATE DATABASE [Test]
GO
USE [Test]
GO
CREATE SCHEMA [enum]
GO
CREATE SCHEMA [lnk]
GO